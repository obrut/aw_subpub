import mqtt from 'mqtt';
import fetch from 'node-fetch';
const mqttAddr = process.env.MQTT;
const sensors = process.env.SENSORS && process.env.SENSORS.split(',');

const getSensor = async (sensor) => {
        const response = await fetch('http://' + sensor);
        const data = await response.text();
        return data;
}

const getSensors = async (client) => {
        sensors.forEach(async (s) => {
                const data = await getSensor(s);
                client.publish('sensors', data)
                console.debug( data );
        })
}

const main = () => {
        const client = mqtt.connect(`mqtt://${mqttAddr}`);
        client.on('connect', () => {
                getSensors(client);
        });
        setTimeout(main, 10000);
}

main();
